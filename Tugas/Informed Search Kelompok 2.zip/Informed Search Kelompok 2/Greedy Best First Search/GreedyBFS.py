from queue import PriorityQueue

heuristic_func = {}
with open('heuristic_val.txt', 'r') as hf:
    for line in hf:
        city, h = line.strip().split()
        heuristic_func[city] = int(h)

graph_func = {}
with open('node_dist_val.txt', 'r') as gf:
    for line in gf:
        source, target, cost = line.strip().split()
        if source not in graph_func:
            graph_func[source] = {}
        graph_func[source][target] = int(cost)
        if target not in graph_func:
            graph_func[target] = {}
        graph_func[target][source] = int(cost)

def GreedyBFS(start, goal, graph_func, heuristic):
    queue = PriorityQueue()
    queue.put((heuristic[start], start))
    visited = set()
    parent = {}

    while not queue.empty():
        current = queue.get()[1]
        
        if current == goal:
            path = []
            
            while current in parent:
                path.append(current)
                current = parent[current]
            path.append(start)
            path.reverse()
            return path
        
        visited.add(current)
        
        for neighbor in graph_func[current]:
            if neighbor not in visited:
                queue.put((heuristic[neighbor], neighbor))
                parent[neighbor] = current
    return None

start = 'Arad'
goal = 'Bucharest'

print("\tGreedy Best-First Search Program!")
print(f"Start: {start}")
print(f"Goal: {goal}")

path = GreedyBFS(start, goal, graph_func, heuristic_func)

if path is None:
    print("\tTidak ada jalur yang ditemukan.")
else:
    print("\tJalur yang ditemukan:")
    print(" -> ".join(path))
