import heapq
from prettytable import PrettyTable

# class untuk priority queue
class priorityQueue:
    def __init__(self):
        self.cities = []

    # menambahkan kota ke queue dengan prioritas cost
    def push(self, city, cost):
        heapq.heappush(self.cities, (cost, city))

    # mengeluarkan kota dengan cost terkecil dari queue
    def pop(self):
        return heapq.heappop(self.cities)[1]

    # cek apakah queue kosong atau tidak
    def isEmpty(self):
        if (self.cities == []):
            return True
        else:
            return False

    # print isi queue
    def check(self):
        print(self.cities)

# class untuk representasi node kota
class ctNode:
    def __init__(self, city, distance):
        self.city = str(city)
        self.distance = str(distance)

# dictionary untuk representasi graph romania
romania = {}

# membaca file romania.txt dan memasukkannya ke dictionary romania
def makedict():
    file = open("romania.txt", 'r')
    for string in file:
        line = string.split(',')
        ct1 = line[0]
        ct2 = line[1]
        dist = int(line[2])
        romania.setdefault(ct1, []).append(ctNode(ct2, dist))
        romania.setdefault(ct2, []).append(ctNode(ct1, dist))

# membaca file romania_sld.txt dan memasukkannya ke dictionary heuristic
def makehuristikdict():
    h = {}
    with open("romania_sld.txt", 'r') as file:
        for line in file:
            line = line.strip().split(",")
            node = line[0].strip()
            sld = int(line[1].strip())
            h[node] = sld
    return h

# mengembalikan nilai heuristic untuk node yang diberikan
def heuristic(node, values):
    if node in values:
        return values[node]
    else:
        return 0

# algoritma A* untuk mencari jalur terpendek dari start ke end
def astar(start, end):
    path = {} # menyimpan path untuk tiap kota
    distance = {} # menyimpan jarak terpendek untuk tiap kota
    q = priorityQueue() # priority queue untuk mengakses kota dengan cost terkecil
    h = makehuristikdict() # dictionary untuk nilai heuristic

    q.push(start, 0) # memasukkan start ke priority queue
    distance[start] = 0 # jarak dari start ke start adalah 0
    path[start] = None # start tidak memiliki parent node
    expandedList = [] # menyimpan kota-kota yang dikunjungi dalam proses pencarian

    while (q.isEmpty() == False):
        current = q.pop() # mengambil kota dengan cost terkecil dari priority queue
        expandedList.append(current) # menambahkan kota ke expandedList
        # Jika node yang diambil adalah end node, maka break dari loop
        if (current == end):
            break

        # Loop melalui node-node tetangga dari current node
        for new in romania[current]:
            g_cost = distance[current] + int(new.distance)

            # Jika node baru belum pernah dikunjungi atau memiliki g_cost lebih rendah dari yang telah dikunjungi
            if (new.city not in distance or g_cost < distance[new.city]):
                # Update jarak dan f_cost
                distance[new.city] = g_cost
                f_cost = g_cost + heuristic(new.city, h)
                # Tambah node baru ke dalam priority queue dan update path
                q.push(new.city, f_cost)
                path[new.city] = current

    # Print hasil akhir dari algoritma A*
    printoutput(start, end, path, distance, expandedList)

# Fungsi untuk print output dari Algoritma A*
def printoutput(start, end, path, distance, expandedlist):
    # inisialisasi variabel untuk menyimpan jalur akhir
    finalpath = []
    i = end

    # membuat jalur akhir dengan mengikuti path dari end hingga start
    while (path.get(i) != None):
        finalpath.append(i)
        i = path[i]
    finalpath.append(start)
    finalpath.reverse()

    # hapus kota yang tidak diperlukan dari jalur akhir
    if len(finalpath) > 2 and finalpath[1] in romania[finalpath[0]]:
        finalpath.pop(1)

    # hapus kota yang tidak diperlukan dari expandedlist
    expandedlist = [city for city in expandedlist if city in finalpath]

    # create table
    table = PrettyTable()
    table.field_names = ["Kota", "Total Jarak"]

    # menambahkan setiap kota dalam jalur akhir beserta jaraknya ke dalam tabel
    for city in finalpath:
        table.add_row([city, distance[city]])

    #   Menampilkan output
    print("Implementasi Algoritma A* untuk masalah Romania")
    print("Kota Asal\t\t\t\t: " + start)
    print("Kota Tujuan\t\t\t\t: " + end)
    print("Jumlah Kota yang Dikunjungi\t\t: " + str(len(expandedlist)))
    print("Kota yang Dikunjungi\t\t\t:")
    print(table)
    
def main():
    makedict()
    src = input("Masukkan kota asal: ")
    dst = input("Masukkan kota tujuan: ")
    astar(src, dst)

if __name__ == "__main__":
    main()
